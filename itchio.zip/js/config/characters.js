// Nicky in the main menu & outro
N = new Character({ align:"left", background:"#FFF", color:"#000", sound:"text_mid" });

// The player in the main menu & outro
p = new Character({ align:"right", background:"#333", color:"#bbb", sound:"text_low" });

// Nicky in the past, the one you can play
n = new Character({ align:"right", background:"#79B8FE", sound:"text_mid" });

// Mother character
m = new Character({ align:"left", background:"#FFF", sound:"text_high" });

// Father character
f = new Character({ align:"left", background:"#333", color:"#bbb", sound:"text_low" });

// Jack, the boyfriend character
j = new Character({ align:"left", background:"#FFF", sound:"text_high" });